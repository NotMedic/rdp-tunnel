// vchannel.h : main header file for the VCHANNEL application
//

#if !defined(AFX_VCHANNEL_H__DB91630C_1360_46C2_8D66_0FC36FE72EB6__INCLUDED_)
#define AFX_VCHANNEL_H__DB91630C_1360_46C2_8D66_0FC36FE72EB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CVchannelApp:
// See vchannel.cpp for the implementation of this class
//

class CVchannelApp : public CWinApp
{
public:
	CVchannelApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVchannelApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CVchannelApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VCHANNEL_H__DB91630C_1360_46C2_8D66_0FC36FE72EB6__INCLUDED_)
