#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

int shut_down=0;

#define BUFSIZE	255

/* signal handler for SIGUSR1 */
void handle_cleanup(int signum);

int main(int argc, char **argv)
{
	ssize_t	bytes_read, bytes_written;
	char buffer[BUFSIZE+1];
	char outbuff[BUFSIZE+1];
	fd_set rfds;
	int retval;
	struct timeval tv;
	unsigned long blocksize;	

	int pipe_in, pipe_out;

	fprintf(stderr,"vc-sample: called with %d args\n", argc);

	/* Set pipe ends to stdin and stdout */
	pipe_in = 0;
	pipe_out = 1;

	/* Initialise signal handler */
	signal(SIGUSR1, handle_cleanup);

	while (!shut_down)
	{
		/* Check if pipe has data */
		FD_ZERO(&rfds);
		FD_SET(0, &rfds);
		
		/* 3 secs wait time */
		memset(&tv, 0, sizeof(struct timeval));
		tv.tv_sec=3;
		retval = select(1,&rfds,NULL,NULL,&tv);

		if (retval == -1)
			perror("vc-sample: select() on pipe_in");
		else if (retval)
		{
			fprintf(stderr, "vc-sample: pipe_in has data\n");
			/* First 32 bits are the buffer size */
			bytes_read=read(pipe_in, (char *)&blocksize,
				sizeof(unsigned long));
fprintf(stderr, "data size is [%d]\n", blocksize);
			if (bytes_read != sizeof(unsigned long))
				fprintf(stderr, "vc-sample: short read of %d buyes instead of blocksize", bytes_read);
			else
			{
				/* Read the block */
				bytes_read=read(pipe_in,buffer,blocksize);
				if (bytes_read == blocksize)
				{
					buffer[bytes_read]='\0';
					fprintf(stderr, "vc-sample: received [%d] bytes of data [%s] from parent\n",
					bytes_read,buffer);
		
					/* Add prefix and send back down vc */
					sprintf(outbuff, "Thank you for your message '%s' which was received and understood", buffer);
					fprintf(stderr, "vc-sample: returning [%s] to parent\n",
						outbuff);
					bytes_written=write(pipe_out,outbuff,strlen(outbuff)+1);
					fprintf(stderr, "vc-sample: written [%d] bytes to parent\n", bytes_written);
				}
				else
					fprintf(stderr, "vc-sample: short read of %d bytes on pipe from rdesktop\n", bytes_read);
			}
		}
	}

	/* Exit process */	
	return(0);
}

void handle_cleanup(int signum)
{
	fprintf(stderr, "vc-sample: caught SIGUSR1...doing cleanup\n");
	shut_down = 1;
}
